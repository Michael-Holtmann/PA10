
/*
 * Day 2:
 */
public class DieDriver
{
    public static void main(String[ ]args )
    {
       
        
        
        
        
        
    }
}
